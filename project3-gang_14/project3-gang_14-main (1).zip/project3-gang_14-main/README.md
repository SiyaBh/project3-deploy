# web_app
Frontend - React
Backend - Node.js + Express.js

Uses PostgreSQL database 

To run web app navigate to root directory and run: npm run dev
